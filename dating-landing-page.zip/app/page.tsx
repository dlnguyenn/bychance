"use client"

import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { Inter } from "next/font/google"
import { useState, useEffect } from "react"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
})

export default function Home() {
  const [imageLoaded, setImageLoaded] = useState(false)
  const [textVisible, setTextVisible] = useState(false)
  const [overlayVisible, setOverlayVisible] = useState(false)

  useEffect(() => {
    // When image is loaded, start the animation sequence
    if (imageLoaded) {
      // First show text
      setTimeout(() => {
        setTextVisible(true)
        // Then darken overlay
        setTimeout(() => {
          setOverlayVisible(true)
        }, 1000)
      }, 100)
    }
  }, [imageLoaded])

  return (
    <main className={`relative min-h-screen w-full overflow-hidden bg-black ${inter.variable}`}>
      {/* Background image with soft gradient blend */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/dating-bg.jpg"
          alt="Two people on a video call with warm lighting"
          fill
          className="object-cover"
          priority
          onLoad={() => setImageLoaded(true)}
        />
        {/* Animated overlay */}
        <div
          className={`absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/60 transition-opacity duration-1000 ease-in-out ${
            overlayVisible ? "opacity-100" : "opacity-0"
          }`}
        />
      </div>

      {/* Content - positioned at bottom to avoid faces */}
      <div
        className={`relative z-10 flex min-h-screen flex-col items-center justify-end px-4 sm:px-6 text-center transition-opacity duration-1000 ease-in-out ${
          textVisible ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="mb-20 sm:mb-24 md:mb-28 space-y-6 sm:space-y-8">
          <h1 className="font-inter text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold leading-tight tracking-tight text-white">
            because dating
            <br />
            shouldn&apos;t feel
            <br className="sm:block hidden" />
            <span className="sm:inline">like scrolling.</span>
          </h1>

          <div className="mx-auto w-full max-w-xl space-y-2">
            <p className="font-inter font-light leading-normal tracking-[-0.225px] text-base sm:text-lg text-gray-300 w-full px-2">
              You enter a pool. You get matched for a 3 minute video call.
            </p>
            <p className="font-inter font-light leading-normal tracking-[-0.225px] text-base sm:text-lg italic text-gray-300 w-full px-2">
              If you vibe, the call continues. If not, you move on – no hard feelings.
            </p>
          </div>

          <p className="mx-auto w-full max-w-xl font-inter font-light leading-normal tracking-[-0.225px] text-base sm:text-lg text-gray-300">
            ready to actually <span className="italic">meet</span> someone, by chance?
          </p>

          <div className="flex flex-col items-center space-y-4">
            <button className="flex items-center gap-2 rounded-full bg-white px-5 py-2 text-sm font-medium text-black transition-all duration-300 hover:bg-black hover:text-white hover:scale-105">
              Join the waitlist <ArrowRight size={16} className="h-3 w-3 sm:h-4 sm:w-4" />
            </button>

            <p className="text-sm text-white opacity-70 text-center">👀 early access coming summer 2025</p>
          </div>
        </div>
      </div>
    </main>
  )
}
